/**
 * Created by Vladimir on 08.11.2015.
 */

homeModule.directive('homePageCategoryBanner', function(){
    return {
        restrict: 'E',
        templateUrl: '../views/components/categoryBanner.html'
    }
});