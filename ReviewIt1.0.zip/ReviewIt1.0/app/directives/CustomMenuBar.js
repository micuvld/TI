/**
 * Created by Vladimir on 08.11.2015.
 */

homeModule.directive('customMenuBar', function() {
   return {
       restrict: 'E',
       templateUrl: '../views/components/customMenuBar.html'
   }
});