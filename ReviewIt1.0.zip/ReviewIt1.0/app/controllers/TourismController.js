/**
 * Created by Vladimir on 08.11.2015.
 */


categoriesModule.controller('TourismController', ['$scope', function($scope){

}]);