/**
 * Created by Vladimir on 08.11.2015.
 */

categoriesModule = angular.module('CategoriesModule', []);