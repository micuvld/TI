/**
 * Created by Vladimir on 08.11.2015.
 */

homeModule = angular.module('HomeModule',['ngRoute', 'CategoriesModule']);